# Milestone 02a — Rules Core

## Goal
Deterministic generic mechanics foundation: definitions, expressions, dice, stats, checks,
effects, conditions.

## Read
`architecture/02-rules-engine.md` §1–§9, §13–§15, §30, §37; `specifications/core-adventure-rules.md`
§2–§7, §12; `specifications/database-schema.md` §9, §14; `testing/testing-strategy.md` §3, §12, §16.

## Implement
Ruleset loader + manifest validation, definition registry, safe expression evaluator, dice
parser and seeded rolling with roll records, attributes/skills/traits, resources with
derivation formulas, modifiers with provenance, checks (simple, opposed, margins), effect
primitives (`modify_resource`, `deal_damage`, `restore_resource`, `modify_attribute`,
`modify_check`, `apply_condition`, `remove_condition`), conditions with stacking rules,
triggers with depth/effect budget.

## Invariants
No `eval`/`exec`. All randomness via the dice service with seed recorded. Every effect is a
registered primitive. Core Adventure numbers live in ruleset data.

## Tests
Reference validation, seeded reproducibility, derived stats for the Frostbridge builds,
check/opposed/margin tables, resource bounds/overflow, condition stacking, trigger cycle
rejection, invalid effect rejection.

## Out of scope
Actions, movement, encounters, combat, NL interpretation.

## Acceptance
`core_adventure` loads and validates; a scripted sequence of checks and effects on two actors
reproduces identical results from recorded seeds.
