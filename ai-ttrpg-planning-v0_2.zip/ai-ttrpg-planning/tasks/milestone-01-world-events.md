# Milestone 01 — World & Event Ledger

## Goal
Implement persistent campaign/world foundations and append-only authoritative events.

## Read
`architecture/01-world-memory.md` §3, §13, §17, §22; `architecture/05-implementation-plan.md` §5–§8; `specifications/database-schema.md` §1–§8, §18–§20, §22; `specifications/time-accounting.md` §3; `testing/testing-strategy.md` §11.

## Implement
Campaign, Timeline, WorldClock, Entity, Location, LocationEdge, Actor, ActorController, Scene, SceneParticipant, Event, EventEntity.

Add event transaction helper, timeline event sequence allocation, world/scene versioning.

## Invariants
Every authoritative projection mutation commits with an Event in the same transaction. Event order is deterministic per timeline. No ordinary hard deletion of fictional history.

## Tests
Create campaign/actor/location/scene; move actor; advance time; force transaction rollback; reopen DB session; verify persistence and event sequence.

## Out of scope
Rules, beliefs, LLMs.

## Acceptance
A deterministic world state can be created/mutated/reloaded with complete causal event history.
