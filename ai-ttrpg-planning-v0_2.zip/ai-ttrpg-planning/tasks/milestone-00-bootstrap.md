# Milestone 00 — Bootstrap

## Goal
Create a reproducible development environment and empty application shell.

## Read
`architecture/05-implementation-plan.md` §2–§4, §22; `PROMPT.md`; `GLOSSARY.md`.

## Context
Read the implementation plan and PROMPT.md. Do not implement game systems yet.

## Likely files
`docker-compose.yml`, `.env.example`, `Makefile`, backend app bootstrap, frontend bootstrap, Alembic config.

## Requirements
- FastAPI backend.
- Next.js/React/TypeScript frontend.
- PostgreSQL.
- Alembic migrations.
- pytest.
- Docker Compose and documented native startup.
- `GET /api/v1/health`.
- Make targets: `dev`, `api`, `web`, `migrate`, `test`.

## Invariants
No game architecture belongs in frontend-only state. LLM credentials remain optional.

## Tests
Health endpoint, database connection, migration up/down smoke test.

## Out of scope
Game models, rules, AI calls.

## Acceptance
Fresh checkout starts successfully and `/api/v1/health` returns OK with database status.
