# Hardware & Model Target (living file)

Fill this in before Milestone 04b and keep it current. `specifications/turn-budget-and-latency.md` §2 explains
why the abstract routing profiles need a concrete floor; the Milestone 04b spike produces the
measured numbers.

```yaml
updated: ___
inference_host:
  gpu: ___
  vram_gb: ___
  system_ram_gb: ___
  cpu: ___
  serving_stack: ___           # llama.cpp / Ollama / vLLM / other; must expose an OpenAI-compatible endpoint
  endpoint: http://___:___/v1
  co_resident_models: 1        # how many models can stay loaded at once
  structured_output_support: ___  # json_schema / grammar / none (prompt-only)
profiles:
  fast_structured:    { model: ___, quant: ___, ctx_window: ___, measured_tps: ___, schema_valid_rate: ___ }
  balanced_reasoning: { model: ___, quant: ___, ctx_window: ___, measured_tps: ___, schema_valid_rate: ___ }
  creative_narrative: { model: ___, quant: ___, ctx_window: ___, measured_tps: ___ }
  deep_world_author:  { model: ___, quant: ___, ctx_window: ___, measured_tps: ___, schema_valid_rate: ___ }
  embedding:          { model: ___, dims: ___, measured_embeds_per_s: ___ }
cloud_fallback:
  enabled: false
  profiles_allowed: []         # e.g. [deep_world_author]
notes: |
  Model-swap cost (seconds): ___
  Observed batching behaviour for concurrent requests: ___
```

Planning assumptions until measured (also stated in `specifications/turn-budget-and-latency.md`): one GPU,
one resident model per profile family, concurrent calls to the same model serialize or batch,
swaps are avoided within a turn.
